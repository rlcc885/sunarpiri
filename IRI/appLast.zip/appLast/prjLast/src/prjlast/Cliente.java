package prjlast;

/*
import com.registradores.iri.schemas.ImporteMoneda;
import com.registradores.iri.schemas.IriWebService;
import com.registradores.iri.schemas.IriWebServiceServiceLocator;
import com.registradores.iri.schemas.Mensaje_acceso;
import com.registradores.iri.schemas.Mensaje_accesoAcceso;
import com.registradores.iri.schemas.Mensaje_accesoAccesoIdioma;
import com.registradores.iri.schemas.Mensaje_acuse;
import com.registradores.iri.schemas.Mensaje_acuseAccion;
import com.registradores.iri.schemas.Mensaje_acuseAccionAcuse;
import com.registradores.iri.schemas.Mensaje_acuseAccionAcuseRetorno;
*/

import java.math.BigDecimal;

import mypackage.ImporteMoneda;
import mypackage.IriWebService;
import mypackage.IriWebServiceServiceLocator;
import mypackage.Mensaje_acceso;
import mypackage.Mensaje_accesoAcceso;
import mypackage.Mensaje_accesoAccesoIdioma;
import mypackage.Mensaje_acuse;
import mypackage.Mensaje_acuseAccion;
import mypackage.Mensaje_acuseAccionAcuse;
import mypackage.Mensaje_acuseAccionAcuseRetorno;



public class Cliente {
    public static void main(String args[]){
        try{
            IriWebServiceServiceLocator locator = new IriWebServiceServiceLocator();
            IriWebService myservice = locator.getIriWebServicePort();
            
            Mensaje_acceso mensaje_acceso = new Mensaje_acceso();
            Mensaje_accesoAcceso acceso = new Mensaje_accesoAcceso();
            acceso.setLogin("angeles");
            acceso.setPassword("epdrdac");
            mensaje_acceso.setAcceso(acceso);
            
            Mensaje_accesoAccesoIdioma idioma =new Mensaje_accesoAccesoIdioma();
            idioma.setCodigo("es");
            idioma.setPais("ES");
            acceso.setIdioma(idioma);
            
            mensaje_acceso.setCod_pais_origen(218);
            mensaje_acceso.setCod_pais_destino(724);
            
            
            
            ImporteMoneda importeMoneda = new ImporteMoneda();
            importeMoneda.setCod_moneda("EUR");
            importeMoneda.setImporte(new BigDecimal("5.12"));
            acceso.setCredito(importeMoneda);
            
            
            
            
            double d = 5.12;
            /*
            BigDecimal bd = getIt();
            DecimalFormat frmt = new DecimalFormat("$0.00");
            String formatted = frmt.format(bd.doubleValue());
            */
            
            Mensaje_acuse rpta = myservice.login(mensaje_acceso);
            
            
            Mensaje_acuseAccion mensaje_acuseAccion = rpta.getAccion();
            System.out.println("cod_referencia " + mensaje_acuseAccion.getCod_referencia()); //-1
            Mensaje_acuseAccionAcuse acuse = mensaje_acuseAccion.getAcuse();
            Mensaje_acuseAccionAcuseRetorno retorno = acuse.getRetorno();
            System.out.println(retorno.getCod_retorno() + retorno.get_value() );
            
            
            //<iri:acuse><iri:retorno cod_retorno="0">OK</iri:retorno><iri:url>http://10.255.255.201:7028/propiedad/pags/iri/loginIRISesion.jsp?JSESSIONID=RWzBKhwMdpmJPq1cN8g8JGJnNqhpvnGvWTdlRnRKgVNqLKVQ5nl9!1050647504!1252077580828</iri:url></iri:acuse></iri:accion></iri:mensaje_acuse>


            
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
}
