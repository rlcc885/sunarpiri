/**
 * Mensaje_respuestaAccionRespuesta.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.registradores.iri.schemas;

public class Mensaje_respuestaAccionRespuesta  implements java.io.Serializable {
    private long cod_solicitud;

    private com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaTipoRespuesta tipoRespuesta;

    private com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaInformacion informacion;

    private com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaReenvio reenvio;  // attribute

    public Mensaje_respuestaAccionRespuesta() {
    }

    public Mensaje_respuestaAccionRespuesta(
           long cod_solicitud,
           com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaTipoRespuesta tipoRespuesta,
           com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaInformacion informacion,
           com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaReenvio reenvio) {
           this.cod_solicitud = cod_solicitud;
           this.tipoRespuesta = tipoRespuesta;
           this.informacion = informacion;
           this.reenvio = reenvio;
    }


    /**
     * Gets the cod_solicitud value for this Mensaje_respuestaAccionRespuesta.
     * 
     * @return cod_solicitud
     */
    public long getCod_solicitud() {
        return cod_solicitud;
    }


    /**
     * Sets the cod_solicitud value for this Mensaje_respuestaAccionRespuesta.
     * 
     * @param cod_solicitud
     */
    public void setCod_solicitud(long cod_solicitud) {
        this.cod_solicitud = cod_solicitud;
    }


    /**
     * Gets the tipoRespuesta value for this Mensaje_respuestaAccionRespuesta.
     * 
     * @return tipoRespuesta
     */
    public com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaTipoRespuesta getTipoRespuesta() {
        return tipoRespuesta;
    }


    /**
     * Sets the tipoRespuesta value for this Mensaje_respuestaAccionRespuesta.
     * 
     * @param tipoRespuesta
     */
    public void setTipoRespuesta(com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaTipoRespuesta tipoRespuesta) {
        this.tipoRespuesta = tipoRespuesta;
    }


    /**
     * Gets the informacion value for this Mensaje_respuestaAccionRespuesta.
     * 
     * @return informacion
     */
    public com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaInformacion getInformacion() {
        return informacion;
    }


    /**
     * Sets the informacion value for this Mensaje_respuestaAccionRespuesta.
     * 
     * @param informacion
     */
    public void setInformacion(com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaInformacion informacion) {
        this.informacion = informacion;
    }


    /**
     * Gets the reenvio value for this Mensaje_respuestaAccionRespuesta.
     * 
     * @return reenvio
     */
    public com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaReenvio getReenvio() {
        return reenvio;
    }


    /**
     * Sets the reenvio value for this Mensaje_respuestaAccionRespuesta.
     * 
     * @param reenvio
     */
    public void setReenvio(com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaReenvio reenvio) {
        this.reenvio = reenvio;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Mensaje_respuestaAccionRespuesta)) return false;
        Mensaje_respuestaAccionRespuesta other = (Mensaje_respuestaAccionRespuesta) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.cod_solicitud == other.getCod_solicitud() &&
            ((this.tipoRespuesta==null && other.getTipoRespuesta()==null) || 
             (this.tipoRespuesta!=null &&
              this.tipoRespuesta.equals(other.getTipoRespuesta()))) &&
            ((this.informacion==null && other.getInformacion()==null) || 
             (this.informacion!=null &&
              this.informacion.equals(other.getInformacion()))) &&
            ((this.reenvio==null && other.getReenvio()==null) || 
             (this.reenvio!=null &&
              this.reenvio.equals(other.getReenvio())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getCod_solicitud()).hashCode();
        if (getTipoRespuesta() != null) {
            _hashCode += getTipoRespuesta().hashCode();
        }
        if (getInformacion() != null) {
            _hashCode += getInformacion().hashCode();
        }
        if (getReenvio() != null) {
            _hashCode += getReenvio().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Mensaje_respuestaAccionRespuesta.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>mensaje_respuesta>accion>respuesta"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("reenvio");
        attrField.setXmlName(new javax.xml.namespace.QName("", "reenvio"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>mensaje_respuesta>accion>respuesta>reenvio"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cod_solicitud");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "cod_solicitud"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoRespuesta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "tipo-respuesta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>mensaje_respuesta>accion>respuesta>tipo-respuesta"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("informacion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "informacion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>mensaje_respuesta>accion>respuesta>informacion"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
