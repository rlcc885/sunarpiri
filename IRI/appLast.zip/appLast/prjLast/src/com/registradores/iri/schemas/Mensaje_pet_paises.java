/**
 * Mensaje_pet_paises.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.registradores.iri.schemas;

public class Mensaje_pet_paises  implements java.io.Serializable {
    private int cod_pais_origen;  // attribute

    public Mensaje_pet_paises() {
    }

    public Mensaje_pet_paises(
           int cod_pais_origen) {
           this.cod_pais_origen = cod_pais_origen;
    }


    /**
     * Gets the cod_pais_origen value for this Mensaje_pet_paises.
     * 
     * @return cod_pais_origen
     */
    public int getCod_pais_origen() {
        return cod_pais_origen;
    }


    /**
     * Sets the cod_pais_origen value for this Mensaje_pet_paises.
     * 
     * @param cod_pais_origen
     */
    public void setCod_pais_origen(int cod_pais_origen) {
        this.cod_pais_origen = cod_pais_origen;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Mensaje_pet_paises)) return false;
        Mensaje_pet_paises other = (Mensaje_pet_paises) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.cod_pais_origen == other.getCod_pais_origen();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getCod_pais_origen();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Mensaje_pet_paises.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_pet_paises"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("cod_pais_origen");
        attrField.setXmlName(new javax.xml.namespace.QName("", "cod_pais_origen"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(attrField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
