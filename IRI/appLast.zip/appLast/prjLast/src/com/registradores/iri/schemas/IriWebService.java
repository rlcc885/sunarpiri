/**
 * IriWebService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.registradores.iri.schemas;

public interface IriWebService extends java.rmi.Remote {
    public com.registradores.iri.schemas.Mensaje_acuse login(com.registradores.iri.schemas.Mensaje_acceso parameter) throws java.rmi.RemoteException;
    public com.registradores.iri.schemas.Mensaje_acuse solicitud(com.registradores.iri.schemas.Mensaje_solicitud parameter) throws java.rmi.RemoteException;
    public com.registradores.iri.schemas.Mensaje_acuse solicitudonline(com.registradores.iri.schemas.Mensaje_solicitud_online parameter) throws java.rmi.RemoteException;
    public com.registradores.iri.schemas.Mensaje_acuse respuesta(com.registradores.iri.schemas.Mensaje_respuesta parameter) throws java.rmi.RemoteException;
    public com.registradores.iri.schemas.Mensaje_respuesta reenvio(com.registradores.iri.schemas.Mensaje_reenvio parameter) throws java.rmi.RemoteException;
    public com.registradores.iri.schemas.Mensaje_acuse retorno(com.registradores.iri.schemas.Mensaje_retorno parameter) throws java.rmi.RemoteException;
    public com.registradores.iri.schemas.Mensaje_lista_paisesPais[] listapaises(com.registradores.iri.schemas.Mensaje_pet_paises parameter) throws java.rmi.RemoteException;
}
