/**
 * Mensaje_accesoAcceso.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.registradores.iri.schemas;

public class Mensaje_accesoAcceso  implements java.io.Serializable {
    private java.lang.String login;

    private java.lang.String password;

    private com.registradores.iri.schemas.Mensaje_accesoAccesoIdioma idioma;

    private com.registradores.iri.schemas.ImporteMoneda credito;

    public Mensaje_accesoAcceso() {
    }

    public Mensaje_accesoAcceso(
           java.lang.String login,
           java.lang.String password,
           com.registradores.iri.schemas.Mensaje_accesoAccesoIdioma idioma,
           com.registradores.iri.schemas.ImporteMoneda credito) {
           this.login = login;
           this.password = password;
           this.idioma = idioma;
           this.credito = credito;
    }


    /**
     * Gets the login value for this Mensaje_accesoAcceso.
     * 
     * @return login
     */
    public java.lang.String getLogin() {
        return login;
    }


    /**
     * Sets the login value for this Mensaje_accesoAcceso.
     * 
     * @param login
     */
    public void setLogin(java.lang.String login) {
        this.login = login;
    }


    /**
     * Gets the password value for this Mensaje_accesoAcceso.
     * 
     * @return password
     */
    public java.lang.String getPassword() {
        return password;
    }


    /**
     * Sets the password value for this Mensaje_accesoAcceso.
     * 
     * @param password
     */
    public void setPassword(java.lang.String password) {
        this.password = password;
    }


    /**
     * Gets the idioma value for this Mensaje_accesoAcceso.
     * 
     * @return idioma
     */
    public com.registradores.iri.schemas.Mensaje_accesoAccesoIdioma getIdioma() {
        return idioma;
    }


    /**
     * Sets the idioma value for this Mensaje_accesoAcceso.
     * 
     * @param idioma
     */
    public void setIdioma(com.registradores.iri.schemas.Mensaje_accesoAccesoIdioma idioma) {
        this.idioma = idioma;
    }


    /**
     * Gets the credito value for this Mensaje_accesoAcceso.
     * 
     * @return credito
     */
    public com.registradores.iri.schemas.ImporteMoneda getCredito() {
        return credito;
    }


    /**
     * Sets the credito value for this Mensaje_accesoAcceso.
     * 
     * @param credito
     */
    public void setCredito(com.registradores.iri.schemas.ImporteMoneda credito) {
        this.credito = credito;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Mensaje_accesoAcceso)) return false;
        Mensaje_accesoAcceso other = (Mensaje_accesoAcceso) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.login==null && other.getLogin()==null) || 
             (this.login!=null &&
              this.login.equals(other.getLogin()))) &&
            ((this.password==null && other.getPassword()==null) || 
             (this.password!=null &&
              this.password.equals(other.getPassword()))) &&
            ((this.idioma==null && other.getIdioma()==null) || 
             (this.idioma!=null &&
              this.idioma.equals(other.getIdioma()))) &&
            ((this.credito==null && other.getCredito()==null) || 
             (this.credito!=null &&
              this.credito.equals(other.getCredito())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getLogin() != null) {
            _hashCode += getLogin().hashCode();
        }
        if (getPassword() != null) {
            _hashCode += getPassword().hashCode();
        }
        if (getIdioma() != null) {
            _hashCode += getIdioma().hashCode();
        }
        if (getCredito() != null) {
            _hashCode += getCredito().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Mensaje_accesoAcceso.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>mensaje_acceso>acceso"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("login");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "login"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("password");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "password"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idioma");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "idioma"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>mensaje_acceso>acceso>idioma"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("credito");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "credito"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "importe-moneda"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
