/**
 * Mensaje_solicitud_onlineAccionSolicitud.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.registradores.iri.schemas;

public class Mensaje_solicitud_onlineAccionSolicitud  implements java.io.Serializable {
    private java.math.BigDecimal importe;

    /* Código ISO 4217 */
    private java.lang.String cod_moneda;

    private com.registradores.iri.schemas.Mensaje_solicitud_onlineAccionSolicitudInformacion informacion;

    private java.lang.String id;  // attribute

    public Mensaje_solicitud_onlineAccionSolicitud() {
    }

    public Mensaje_solicitud_onlineAccionSolicitud(
           java.math.BigDecimal importe,
           java.lang.String cod_moneda,
           com.registradores.iri.schemas.Mensaje_solicitud_onlineAccionSolicitudInformacion informacion,
           java.lang.String id) {
           this.importe = importe;
           this.cod_moneda = cod_moneda;
           this.informacion = informacion;
           this.id = id;
    }


    /**
     * Gets the importe value for this Mensaje_solicitud_onlineAccionSolicitud.
     * 
     * @return importe
     */
    public java.math.BigDecimal getImporte() {
        return importe;
    }


    /**
     * Sets the importe value for this Mensaje_solicitud_onlineAccionSolicitud.
     * 
     * @param importe
     */
    public void setImporte(java.math.BigDecimal importe) {
        this.importe = importe;
    }


    /**
     * Gets the cod_moneda value for this Mensaje_solicitud_onlineAccionSolicitud.
     * 
     * @return cod_moneda   * Código ISO 4217
     */
    public java.lang.String getCod_moneda() {
        return cod_moneda;
    }


    /**
     * Sets the cod_moneda value for this Mensaje_solicitud_onlineAccionSolicitud.
     * 
     * @param cod_moneda   * Código ISO 4217
     */
    public void setCod_moneda(java.lang.String cod_moneda) {
        this.cod_moneda = cod_moneda;
    }


    /**
     * Gets the informacion value for this Mensaje_solicitud_onlineAccionSolicitud.
     * 
     * @return informacion
     */
    public com.registradores.iri.schemas.Mensaje_solicitud_onlineAccionSolicitudInformacion getInformacion() {
        return informacion;
    }


    /**
     * Sets the informacion value for this Mensaje_solicitud_onlineAccionSolicitud.
     * 
     * @param informacion
     */
    public void setInformacion(com.registradores.iri.schemas.Mensaje_solicitud_onlineAccionSolicitudInformacion informacion) {
        this.informacion = informacion;
    }


    /**
     * Gets the id value for this Mensaje_solicitud_onlineAccionSolicitud.
     * 
     * @return id
     */
    public java.lang.String getId() {
        return id;
    }


    /**
     * Sets the id value for this Mensaje_solicitud_onlineAccionSolicitud.
     * 
     * @param id
     */
    public void setId(java.lang.String id) {
        this.id = id;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Mensaje_solicitud_onlineAccionSolicitud)) return false;
        Mensaje_solicitud_onlineAccionSolicitud other = (Mensaje_solicitud_onlineAccionSolicitud) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.importe==null && other.getImporte()==null) || 
             (this.importe!=null &&
              this.importe.equals(other.getImporte()))) &&
            ((this.cod_moneda==null && other.getCod_moneda()==null) || 
             (this.cod_moneda!=null &&
              this.cod_moneda.equals(other.getCod_moneda()))) &&
            ((this.informacion==null && other.getInformacion()==null) || 
             (this.informacion!=null &&
              this.informacion.equals(other.getInformacion()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getImporte() != null) {
            _hashCode += getImporte().hashCode();
        }
        if (getCod_moneda() != null) {
            _hashCode += getCod_moneda().hashCode();
        }
        if (getInformacion() != null) {
            _hashCode += getInformacion().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Mensaje_solicitud_onlineAccionSolicitud.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>mensaje_solicitud_online>accion>solicitud"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("id");
        attrField.setXmlName(new javax.xml.namespace.QName("", "id"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("importe");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "importe"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cod_moneda");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "cod_moneda"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("informacion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "informacion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>mensaje_solicitud_online>accion>solicitud>informacion"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
