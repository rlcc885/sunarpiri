/**
 * IriWebServiceBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.registradores.iri.schemas;

public class IriWebServiceBindingStub extends org.apache.axis.client.Stub implements com.registradores.iri.schemas.IriWebService {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[7];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("login");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "mensaje_acceso"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_acceso"), com.registradores.iri.schemas.Mensaje_acceso.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_acuse"));
        oper.setReturnClass(com.registradores.iri.schemas.Mensaje_acuse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "mensaje_acuse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("solicitud");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "mensaje_solicitud"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_solicitud"), com.registradores.iri.schemas.Mensaje_solicitud.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_acuse"));
        oper.setReturnClass(com.registradores.iri.schemas.Mensaje_acuse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "mensaje_acuse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("solicitudonline");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "mensaje_solicitud_online"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_solicitud_online"), com.registradores.iri.schemas.Mensaje_solicitud_online.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_acuse"));
        oper.setReturnClass(com.registradores.iri.schemas.Mensaje_acuse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "mensaje_acuse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("respuesta");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "mensaje_respuesta"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_respuesta"), com.registradores.iri.schemas.Mensaje_respuesta.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_acuse"));
        oper.setReturnClass(com.registradores.iri.schemas.Mensaje_acuse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "mensaje_acuse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("reenvio");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "mensaje_reenvio"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_reenvio"), com.registradores.iri.schemas.Mensaje_reenvio.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_respuesta"));
        oper.setReturnClass(com.registradores.iri.schemas.Mensaje_respuesta.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "mensaje_respuesta"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("retorno");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "mensaje_retorno"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_retorno"), com.registradores.iri.schemas.Mensaje_retorno.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_acuse"));
        oper.setReturnClass(com.registradores.iri.schemas.Mensaje_acuse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "mensaje_acuse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("listapaises");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "mensaje_pet_paises"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_pet_paises"), com.registradores.iri.schemas.Mensaje_pet_paises.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_lista_paises"));
        oper.setReturnClass(com.registradores.iri.schemas.Mensaje_lista_paisesPais[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "mensaje_lista_paises"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "pais"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

    }

    public IriWebServiceBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public IriWebServiceBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public IriWebServiceBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>>>mensaje_respuesta>accion>respuesta>informacion>fichero>tipo");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaInformacionFicheroTipo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>>>mensaje_solicitud_online>accion>solicitud>informacion>fichero>tipo");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_solicitud_onlineAccionSolicitudInformacionFicheroTipo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>>mensaje_acuse>accion>acuse>retorno>cod_retorno");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_acuseAccionAcuseRetornoCod_retorno.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>>mensaje_respuesta>accion>respuesta>informacion>fichero");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaInformacionFichero.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>>mensaje_solicitud_online>accion>solicitud>informacion>fichero");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_solicitud_onlineAccionSolicitudInformacionFichero.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>mensaje_acceso>acceso>idioma>codigo");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>mensaje_acceso>acceso>idioma>pais");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>mensaje_acuse>accion>acuse>cod_solicitud");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_acuseAccionAcuseCod_solicitud.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>mensaje_acuse>accion>acuse>retorno");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_acuseAccionAcuseRetorno.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>mensaje_respuesta>accion>respuesta>informacion");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaInformacion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>mensaje_respuesta>accion>respuesta>reenvio");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaReenvio.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>mensaje_respuesta>accion>respuesta>tipo-respuesta");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_respuestaAccionRespuestaTipoRespuesta.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>mensaje_solicitud_online>accion>solicitud>importe");
            cachedSerQNames.add(qName);
            cls = java.math.BigDecimal.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>>mensaje_solicitud_online>accion>solicitud>informacion");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_solicitud_onlineAccionSolicitudInformacion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>mensaje_acceso>acceso>idioma");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_accesoAccesoIdioma.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>mensaje_acuse>accion>acuse");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_acuseAccionAcuse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>mensaje_reenvio>accion>reenvio");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_reenvioAccionReenvio.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>mensaje_respuesta>accion>respuesta");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_respuestaAccionRespuesta.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>mensaje_retorno>accion>retorno");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_retornoAccionRetorno.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>mensaje_solicitud>accion>solicitud");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_solicitudAccionSolicitud.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>mensaje_solicitud_online>accion>solicitud");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_solicitud_onlineAccionSolicitud.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>mensaje_acceso>acceso");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_accesoAcceso.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>mensaje_acuse>accion");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_acuseAccion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>mensaje_lista_paises>pais");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_lista_paisesPais.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>mensaje_reenvio>accion");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_reenvioAccion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>mensaje_respuesta>accion");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_respuestaAccion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>mensaje_retorno>accion");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_retornoAccion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>mensaje_solicitud>accion");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_solicitudAccion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>mensaje_solicitud_online>accion");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_solicitud_onlineAccion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">importe-moneda>cod_moneda");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">importe-moneda>importe");
            cachedSerQNames.add(qName);
            cls = java.math.BigDecimal.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_acceso");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_acceso.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_acuse");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_acuse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_lista_paises");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_lista_paisesPais[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>mensaje_lista_paises>pais");
            qName2 = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "pais");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_pet_paises");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_pet_paises.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_reenvio");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_reenvio.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_respuesta");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_respuesta.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_retorno");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_retorno.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_solicitud");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_solicitud.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_solicitud_online");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.Mensaje_solicitud_online.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "importe-moneda");
            cachedSerQNames.add(qName);
            cls = com.registradores.iri.schemas.ImporteMoneda.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public com.registradores.iri.schemas.Mensaje_acuse login(com.registradores.iri.schemas.Mensaje_acceso parameter) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("login");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "login"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameter});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.registradores.iri.schemas.Mensaje_acuse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.registradores.iri.schemas.Mensaje_acuse) org.apache.axis.utils.JavaUtils.convert(_resp, com.registradores.iri.schemas.Mensaje_acuse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.registradores.iri.schemas.Mensaje_acuse solicitud(com.registradores.iri.schemas.Mensaje_solicitud parameter) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("solicitud");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "solicitud"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameter});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.registradores.iri.schemas.Mensaje_acuse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.registradores.iri.schemas.Mensaje_acuse) org.apache.axis.utils.JavaUtils.convert(_resp, com.registradores.iri.schemas.Mensaje_acuse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.registradores.iri.schemas.Mensaje_acuse solicitudonline(com.registradores.iri.schemas.Mensaje_solicitud_online parameter) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("solicitudonline");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "solicitudonline"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameter});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.registradores.iri.schemas.Mensaje_acuse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.registradores.iri.schemas.Mensaje_acuse) org.apache.axis.utils.JavaUtils.convert(_resp, com.registradores.iri.schemas.Mensaje_acuse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.registradores.iri.schemas.Mensaje_acuse respuesta(com.registradores.iri.schemas.Mensaje_respuesta parameter) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("respuesta");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "respuesta"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameter});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.registradores.iri.schemas.Mensaje_acuse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.registradores.iri.schemas.Mensaje_acuse) org.apache.axis.utils.JavaUtils.convert(_resp, com.registradores.iri.schemas.Mensaje_acuse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.registradores.iri.schemas.Mensaje_respuesta reenvio(com.registradores.iri.schemas.Mensaje_reenvio parameter) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("reenvio");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "reenvio"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameter});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.registradores.iri.schemas.Mensaje_respuesta) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.registradores.iri.schemas.Mensaje_respuesta) org.apache.axis.utils.JavaUtils.convert(_resp, com.registradores.iri.schemas.Mensaje_respuesta.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.registradores.iri.schemas.Mensaje_acuse retorno(com.registradores.iri.schemas.Mensaje_retorno parameter) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("retorno");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "retorno"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameter});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.registradores.iri.schemas.Mensaje_acuse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.registradores.iri.schemas.Mensaje_acuse) org.apache.axis.utils.JavaUtils.convert(_resp, com.registradores.iri.schemas.Mensaje_acuse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.registradores.iri.schemas.Mensaje_lista_paisesPais[] listapaises(com.registradores.iri.schemas.Mensaje_pet_paises parameter) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("listapaises");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "listapaises"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameter});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.registradores.iri.schemas.Mensaje_lista_paisesPais[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.registradores.iri.schemas.Mensaje_lista_paisesPais[]) org.apache.axis.utils.JavaUtils.convert(_resp, com.registradores.iri.schemas.Mensaje_lista_paisesPais[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
