/**
 * Mensaje_solicitudAccion.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package mypackage;

public class Mensaje_solicitudAccion  implements java.io.Serializable {
    private long cod_referencia;

    private mypackage.Mensaje_solicitudAccionSolicitud[] solicitud;

    private java.lang.String referencia;

    private java.lang.String email_destino;

    public Mensaje_solicitudAccion() {
    }

    public Mensaje_solicitudAccion(
           long cod_referencia,
           mypackage.Mensaje_solicitudAccionSolicitud[] solicitud,
           java.lang.String referencia,
           java.lang.String email_destino) {
           this.cod_referencia = cod_referencia;
           this.solicitud = solicitud;
           this.referencia = referencia;
           this.email_destino = email_destino;
    }


    /**
     * Gets the cod_referencia value for this Mensaje_solicitudAccion.
     * 
     * @return cod_referencia
     */
    public long getCod_referencia() {
        return cod_referencia;
    }


    /**
     * Sets the cod_referencia value for this Mensaje_solicitudAccion.
     * 
     * @param cod_referencia
     */
    public void setCod_referencia(long cod_referencia) {
        this.cod_referencia = cod_referencia;
    }


    /**
     * Gets the solicitud value for this Mensaje_solicitudAccion.
     * 
     * @return solicitud
     */
    public mypackage.Mensaje_solicitudAccionSolicitud[] getSolicitud() {
        return solicitud;
    }


    /**
     * Sets the solicitud value for this Mensaje_solicitudAccion.
     * 
     * @param solicitud
     */
    public void setSolicitud(mypackage.Mensaje_solicitudAccionSolicitud[] solicitud) {
        this.solicitud = solicitud;
    }

    public mypackage.Mensaje_solicitudAccionSolicitud getSolicitud(int i) {
        return this.solicitud[i];
    }

    public void setSolicitud(int i, mypackage.Mensaje_solicitudAccionSolicitud _value) {
        this.solicitud[i] = _value;
    }


    /**
     * Gets the referencia value for this Mensaje_solicitudAccion.
     * 
     * @return referencia
     */
    public java.lang.String getReferencia() {
        return referencia;
    }


    /**
     * Sets the referencia value for this Mensaje_solicitudAccion.
     * 
     * @param referencia
     */
    public void setReferencia(java.lang.String referencia) {
        this.referencia = referencia;
    }


    /**
     * Gets the email_destino value for this Mensaje_solicitudAccion.
     * 
     * @return email_destino
     */
    public java.lang.String getEmail_destino() {
        return email_destino;
    }


    /**
     * Sets the email_destino value for this Mensaje_solicitudAccion.
     * 
     * @param email_destino
     */
    public void setEmail_destino(java.lang.String email_destino) {
        this.email_destino = email_destino;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Mensaje_solicitudAccion)) return false;
        Mensaje_solicitudAccion other = (Mensaje_solicitudAccion) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.cod_referencia == other.getCod_referencia() &&
            ((this.solicitud==null && other.getSolicitud()==null) || 
             (this.solicitud!=null &&
              java.util.Arrays.equals(this.solicitud, other.getSolicitud()))) &&
            ((this.referencia==null && other.getReferencia()==null) || 
             (this.referencia!=null &&
              this.referencia.equals(other.getReferencia()))) &&
            ((this.email_destino==null && other.getEmail_destino()==null) || 
             (this.email_destino!=null &&
              this.email_destino.equals(other.getEmail_destino())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getCod_referencia()).hashCode();
        if (getSolicitud() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSolicitud());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSolicitud(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getReferencia() != null) {
            _hashCode += getReferencia().hashCode();
        }
        if (getEmail_destino() != null) {
            _hashCode += getEmail_destino().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Mensaje_solicitudAccion.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>mensaje_solicitud>accion"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cod_referencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "cod_referencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solicitud");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "solicitud"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>mensaje_solicitud>accion>solicitud"));
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("referencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "referencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("email_destino");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "email_destino"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
