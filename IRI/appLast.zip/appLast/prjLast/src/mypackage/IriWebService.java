/**
 * IriWebService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package mypackage;

public interface IriWebService extends java.rmi.Remote {
    public mypackage.Mensaje_acuse login(mypackage.Mensaje_acceso parameter) throws java.rmi.RemoteException;
    public mypackage.Mensaje_acuse solicitud(mypackage.Mensaje_solicitud parameter) throws java.rmi.RemoteException;
    public mypackage.Mensaje_acuse solicitudonline(mypackage.Mensaje_solicitud_online parameter) throws java.rmi.RemoteException;
    public mypackage.Mensaje_acuse respuesta(mypackage.Mensaje_respuesta parameter) throws java.rmi.RemoteException;
    public mypackage.Mensaje_respuesta reenvio(mypackage.Mensaje_reenvio parameter) throws java.rmi.RemoteException;
    public mypackage.Mensaje_acuse retorno(mypackage.Mensaje_retorno parameter) throws java.rmi.RemoteException;
    public mypackage.Mensaje_lista_paisesPais[] listapaises(mypackage.Mensaje_pet_paises parameter) throws java.rmi.RemoteException;
}
