/**
 * Mensaje_accesoAccesoIdioma.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package mypackage;

public class Mensaje_accesoAccesoIdioma  implements java.io.Serializable {
    /* Códigos ISO 639-1
     * 
     * es 	español (o castellano)
     * 
     * fr 	francés
     * 
     * it 	italiano
     * 
     * en 	inglés
     * 
     * de 	alemán
     * 
     * etc... */
    private java.lang.String codigo;

    /* Códigos ISO 3166-1
     * 
     * ES España
     * 
     * FR Francia
     * 
     * GB Reino Unido
     * 
     * etc... */
    private java.lang.String pais;

    public Mensaje_accesoAccesoIdioma() {
    }

    public Mensaje_accesoAccesoIdioma(
           java.lang.String codigo,
           java.lang.String pais) {
           this.codigo = codigo;
           this.pais = pais;
    }


    /**
     * Gets the codigo value for this Mensaje_accesoAccesoIdioma.
     * 
     * @return codigo   * Códigos ISO 639-1
     * 
     * es 	español (o castellano)
     * 
     * fr 	francés
     * 
     * it 	italiano
     * 
     * en 	inglés
     * 
     * de 	alemán
     * 
     * etc...
     */
    public java.lang.String getCodigo() {
        return codigo;
    }


    /**
     * Sets the codigo value for this Mensaje_accesoAccesoIdioma.
     * 
     * @param codigo   * Códigos ISO 639-1
     * 
     * es 	español (o castellano)
     * 
     * fr 	francés
     * 
     * it 	italiano
     * 
     * en 	inglés
     * 
     * de 	alemán
     * 
     * etc...
     */
    public void setCodigo(java.lang.String codigo) {
        this.codigo = codigo;
    }


    /**
     * Gets the pais value for this Mensaje_accesoAccesoIdioma.
     * 
     * @return pais   * Códigos ISO 3166-1
     * 
     * ES España
     * 
     * FR Francia
     * 
     * GB Reino Unido
     * 
     * etc...
     */
    public java.lang.String getPais() {
        return pais;
    }


    /**
     * Sets the pais value for this Mensaje_accesoAccesoIdioma.
     * 
     * @param pais   * Códigos ISO 3166-1
     * 
     * ES España
     * 
     * FR Francia
     * 
     * GB Reino Unido
     * 
     * etc...
     */
    public void setPais(java.lang.String pais) {
        this.pais = pais;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Mensaje_accesoAccesoIdioma)) return false;
        Mensaje_accesoAccesoIdioma other = (Mensaje_accesoAccesoIdioma) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigo==null && other.getCodigo()==null) || 
             (this.codigo!=null &&
              this.codigo.equals(other.getCodigo()))) &&
            ((this.pais==null && other.getPais()==null) || 
             (this.pais!=null &&
              this.pais.equals(other.getPais())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigo() != null) {
            _hashCode += getCodigo().hashCode();
        }
        if (getPais() != null) {
            _hashCode += getPais().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Mensaje_accesoAccesoIdioma.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>mensaje_acceso>acceso>idioma"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "codigo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pais");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "pais"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
