/**
 * Mensaje_acceso.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package mypackage;

public class Mensaje_acceso  implements java.io.Serializable {
    private long cod_pais_destino;

    private long cod_pais_origen;

    private mypackage.Mensaje_accesoAcceso acceso;

    public Mensaje_acceso() {
    }

    public Mensaje_acceso(
           long cod_pais_destino,
           long cod_pais_origen,
           mypackage.Mensaje_accesoAcceso acceso) {
           this.cod_pais_destino = cod_pais_destino;
           this.cod_pais_origen = cod_pais_origen;
           this.acceso = acceso;
    }


    /**
     * Gets the cod_pais_destino value for this Mensaje_acceso.
     * 
     * @return cod_pais_destino
     */
    public long getCod_pais_destino() {
        return cod_pais_destino;
    }


    /**
     * Sets the cod_pais_destino value for this Mensaje_acceso.
     * 
     * @param cod_pais_destino
     */
    public void setCod_pais_destino(long cod_pais_destino) {
        this.cod_pais_destino = cod_pais_destino;
    }


    /**
     * Gets the cod_pais_origen value for this Mensaje_acceso.
     * 
     * @return cod_pais_origen
     */
    public long getCod_pais_origen() {
        return cod_pais_origen;
    }


    /**
     * Sets the cod_pais_origen value for this Mensaje_acceso.
     * 
     * @param cod_pais_origen
     */
    public void setCod_pais_origen(long cod_pais_origen) {
        this.cod_pais_origen = cod_pais_origen;
    }


    /**
     * Gets the acceso value for this Mensaje_acceso.
     * 
     * @return acceso
     */
    public mypackage.Mensaje_accesoAcceso getAcceso() {
        return acceso;
    }


    /**
     * Sets the acceso value for this Mensaje_acceso.
     * 
     * @param acceso
     */
    public void setAcceso(mypackage.Mensaje_accesoAcceso acceso) {
        this.acceso = acceso;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Mensaje_acceso)) return false;
        Mensaje_acceso other = (Mensaje_acceso) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.cod_pais_destino == other.getCod_pais_destino() &&
            this.cod_pais_origen == other.getCod_pais_origen() &&
            ((this.acceso==null && other.getAcceso()==null) || 
             (this.acceso!=null &&
              this.acceso.equals(other.getAcceso())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getCod_pais_destino()).hashCode();
        _hashCode += new Long(getCod_pais_origen()).hashCode();
        if (getAcceso() != null) {
            _hashCode += getAcceso().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Mensaje_acceso.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">mensaje_acceso"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cod_pais_destino");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "cod_pais_destino"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cod_pais_origen");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "cod_pais_origen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("acceso");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "acceso"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>mensaje_acceso>acceso"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
