/**
 * Mensaje_respuestaAccion.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package mypackage;

public class Mensaje_respuestaAccion  implements java.io.Serializable {
    private long cod_referencia;

    private mypackage.Mensaje_respuestaAccionRespuesta respuesta;

    public Mensaje_respuestaAccion() {
    }

    public Mensaje_respuestaAccion(
           long cod_referencia,
           mypackage.Mensaje_respuestaAccionRespuesta respuesta) {
           this.cod_referencia = cod_referencia;
           this.respuesta = respuesta;
    }


    /**
     * Gets the cod_referencia value for this Mensaje_respuestaAccion.
     * 
     * @return cod_referencia
     */
    public long getCod_referencia() {
        return cod_referencia;
    }


    /**
     * Sets the cod_referencia value for this Mensaje_respuestaAccion.
     * 
     * @param cod_referencia
     */
    public void setCod_referencia(long cod_referencia) {
        this.cod_referencia = cod_referencia;
    }


    /**
     * Gets the respuesta value for this Mensaje_respuestaAccion.
     * 
     * @return respuesta
     */
    public mypackage.Mensaje_respuestaAccionRespuesta getRespuesta() {
        return respuesta;
    }


    /**
     * Sets the respuesta value for this Mensaje_respuestaAccion.
     * 
     * @param respuesta
     */
    public void setRespuesta(mypackage.Mensaje_respuestaAccionRespuesta respuesta) {
        this.respuesta = respuesta;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Mensaje_respuestaAccion)) return false;
        Mensaje_respuestaAccion other = (Mensaje_respuestaAccion) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.cod_referencia == other.getCod_referencia() &&
            ((this.respuesta==null && other.getRespuesta()==null) || 
             (this.respuesta!=null &&
              this.respuesta.equals(other.getRespuesta())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getCod_referencia()).hashCode();
        if (getRespuesta() != null) {
            _hashCode += getRespuesta().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Mensaje_respuestaAccion.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>mensaje_respuesta>accion"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cod_referencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "cod_referencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("respuesta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "respuesta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>mensaje_respuesta>accion>respuesta"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
