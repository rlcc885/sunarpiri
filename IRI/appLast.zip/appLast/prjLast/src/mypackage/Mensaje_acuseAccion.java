/**
 * Mensaje_acuseAccion.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package mypackage;

public class Mensaje_acuseAccion  implements java.io.Serializable {
    private java.lang.Long cod_referencia;

    private mypackage.Mensaje_acuseAccionAcuse acuse;

    public Mensaje_acuseAccion() {
    }

    public Mensaje_acuseAccion(
           java.lang.Long cod_referencia,
           mypackage.Mensaje_acuseAccionAcuse acuse) {
           this.cod_referencia = cod_referencia;
           this.acuse = acuse;
    }


    /**
     * Gets the cod_referencia value for this Mensaje_acuseAccion.
     * 
     * @return cod_referencia
     */
    public java.lang.Long getCod_referencia() {
        return cod_referencia;
    }


    /**
     * Sets the cod_referencia value for this Mensaje_acuseAccion.
     * 
     * @param cod_referencia
     */
    public void setCod_referencia(java.lang.Long cod_referencia) {
        this.cod_referencia = cod_referencia;
    }


    /**
     * Gets the acuse value for this Mensaje_acuseAccion.
     * 
     * @return acuse
     */
    public mypackage.Mensaje_acuseAccionAcuse getAcuse() {
        return acuse;
    }


    /**
     * Sets the acuse value for this Mensaje_acuseAccion.
     * 
     * @param acuse
     */
    public void setAcuse(mypackage.Mensaje_acuseAccionAcuse acuse) {
        this.acuse = acuse;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Mensaje_acuseAccion)) return false;
        Mensaje_acuseAccion other = (Mensaje_acuseAccion) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.cod_referencia==null && other.getCod_referencia()==null) || 
             (this.cod_referencia!=null &&
              this.cod_referencia.equals(other.getCod_referencia()))) &&
            ((this.acuse==null && other.getAcuse()==null) || 
             (this.acuse!=null &&
              this.acuse.equals(other.getAcuse())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCod_referencia() != null) {
            _hashCode += getCod_referencia().hashCode();
        }
        if (getAcuse() != null) {
            _hashCode += getAcuse().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Mensaje_acuseAccion.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>mensaje_acuse>accion"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cod_referencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "cod_referencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("acuse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", "acuse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://registradores.com/iri/schemas", ">>>mensaje_acuse>accion>acuse"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
